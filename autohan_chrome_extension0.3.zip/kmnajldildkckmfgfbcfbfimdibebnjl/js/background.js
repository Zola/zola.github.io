var currentLanguage = "1"; // 假設當前網頁是繁體漢字
chrome.action.onClicked.addListener(function(tab) {
        if (currentLanguage === "1"){
             chrome.scripting.executeScript({
    target: {tabId: tab.id}, // 指定目标标签页
    files: ["js/fan.js"]   // 文件路径必须是数组
});
                chrome.action.setBadgeBackgroundColor({color: 'rgba(255, 178, 178, 0.35)'});
                chrome.action.setBadgeText({text: '简'});
            chrome.scripting.executeScript({
    target: {tabId: tab.id}, // 必须指定目标标签页
    func: () => {
        document.body.style.backgroundColor = "#f1f7ff"; // 修改背景色
    }
});
                chrome.action.setIcon({ path: "../han38.png" });
                currentLanguage = "0";
        }
        else{
               chrome.scripting.executeScript({
    target: {tabId: tab.id}, // 指定目标标签页
    files: ["js/jian.js"]   // 文件路径必须是数组
});
                chrome.action.setBadgeBackgroundColor({color: 'rgba(162, 201, 255, 0.43)'});
                chrome.action.setBadgeText({text: '繁'});
                chrome.scripting.executeScript({
    target: {tabId: tab.id}, // 必须指定目标标签页
    func: () => {
        document.body.style.backgroundColor = "#fff1f1"; // 修改背景色
    }
});
                chrome.action.setIcon({ path: "../icon32.png" });
                currentLanguage = "1";
        }
});

function menuClicked(info, tab) {

if (info.menuItemId == "AutoHan_Fan"){
    chrome.action.setBadgeBackgroundColor({color: 'rgba(255, 178, 178, 0.35)'});
    chrome.action.setBadgeText({text: '简'});
    chrome.scripting.executeScript({
    target: {tabId: tab.id}, // 指定目标标签页
    files: ["js/fan.js"]   // 文件路径必须是数组
});
    chrome.action.setIcon({ path: "../han38.png" });
    }
if (info.menuItemId == "AutoHan_Jian"){
    chrome.action.setBadgeBackgroundColor({color: 'rgba(162, 201, 255, 0.43)'});
    chrome.action.setBadgeText({text: '繁'});
    chrome.scripting.executeScript({
    target: {tabId: tab.id}, // 指定目标标签页
    files: ["js/jian.js"]   // 文件路径必须是数组
}); 
    chrome.action.setIcon({ path: "../icon32.png" });
    }   
}
chrome.contextMenus.create({
    title: "轉為繁體",
    contexts: ["all"],
    id: "AutoHan_Fan"
}, () => {
    if (chrome.runtime.lastError) {
        console.error(`Error creating context menu: ${chrome.runtime.lastError.message}`);
    }
});
chrome.contextMenus.create({
    title: "转为简体",
    contexts: ["all"],
    id: "AutoHan_Jian"
}, () => {
    if (chrome.runtime.lastError) {
        console.error(`Error creating context menu: ${chrome.runtime.lastError.message}`);
    }
});
chrome.contextMenus.onClicked.addListener(menuClicked);
//下面的JS

chrome.runtime.setUninstallURL("https://www.autohan.org/uninstall-feedback", () => {
    if (chrome.runtime.lastError) {
        console.error(`Error setting uninstall URL: ${chrome.runtime.lastError}`);
    }
});
