var Browser_isFt =''
const language = window.navigator.userLanguage || window.navigator.language;
var TEXT_S_T = "";
if (language.match(/zh-c/i) != null){TEXT_S_T = 0;}
        else if (language.match(/zh-h/i) != null){TEXT_S_T = 1}
        else if (language.match(/zh-t/i) != null){TEXT_S_T = 1}
        else if (language.match(/zh/i) != null){TEXT_S_T = 1}
        else if (language.match(/jp/i) != null){TEXT_S_T = 1}
        else if (language.match(/ja/i) != null){TEXT_S_T = 1}
        else if (language.match(/ko/i) != null){TEXT_S_T = 1}
        else {TEXT_S_T = 0}
console.log('language: ' + language + ' red!');
console.log('TEXT_S_T: ' + TEXT_S_T + ' red!');
chrome.browserAction.onClicked.addListener(function(tab) {
        console.log('Turning ' + tab.url + ' red!');
        console.log('USERAGENT:'+window.navigator.language);
        console.log('Turning ' + chrome.runtime.getURL("js/autohan.js")+ ' red!');;  
        if (TEXT_S_T == 0){
                chrome.tabs.executeScript(null, {file: "js/fan.js"});
                chrome.browserAction.setBadgeBackgroundColor({color: '#ba8958'});
                chrome.browserAction.setBadgeText({text: '简'});
                chrome.tabs.executeScript({code: 'document.body.style.backgroundColor="#fdeedf"'});
                chrome.browserAction.setIcon({path: 'han38.png'});
                TEXT_S_T = 1;
        }
        else{
                chrome.tabs.executeScript(null, {file: "js/jian.js"});
                chrome.browserAction.setBadgeBackgroundColor({color: '#4f86d0'});
                chrome.browserAction.setBadgeText({text: '繁'});
                chrome.tabs.executeScript({code: 'document.body.style.backgroundColor="#c2dcff"'});
                chrome.browserAction.setIcon({path: 'icon32.png'});
                TEXT_S_T = 0;
        }
});
const TEXT_FAN = "AutoHan_Fan";
const TEXT_JIAN = "AutoHan_Jian";
function menuClicked(info, tab) {

if (info.menuItemId == TEXT_FAN){
    chrome.tabs.executeScript(null, {file: "js/fan.js"});
    chrome.browserAction.setIcon({path: 'han38.png'});
    }
if (info.menuItemId == TEXT_JIAN){
    chrome.tabs.executeScript(null, {file: "js/jian.js"});
    chrome.browserAction.setIcon({path: 'icon32.png'}); 
    }   
}
chrome.contextMenus.create({
    title: "轉為繁體",
    contexts: ["all"],
    id: TEXT_FAN
});
chrome.contextMenus.create({
    title: "转为简体",
    contexts: ["all"],
    id: TEXT_JIAN
});
chrome.contextMenus.onClicked.addListener(menuClicked)
chrome.contextMenus.onClicked.addListener(menuClicked)