a simple chrome extension for AutoHan
